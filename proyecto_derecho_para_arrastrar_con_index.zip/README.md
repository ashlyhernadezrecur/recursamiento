# Proyecto: Licenciatura en Derecho

Este repositorio contiene un conjunto de páginas web desarrolladas como parte del submódulo **Desarrollo de Aplicaciones Web**. 
El proyecto está enfocado en la **Licenciatura en Derecho** y presenta información introductoria, fundamentos, 
ejercicios interactivos y una conclusión final.

## 📂 Archivos principales

- **portada.html** → Página inicial con portada e índice de contenidos.
- **prac1Lic.html** → Presentación del submódulo *Fundamentos del Derecho*.
- **ejercicio2.html** → Página sobre *Fundamentos del Derecho* con ejemplos y recursos.
- **Ejer3.html** → Autoevaluación de Derecho Constitucional (formulario interactivo).
- **conclusion.html** → Conclusión general y reflexiones sobre la Licenciatura en Derecho.

## 🚀 Publicación con GitHub Pages

1. Crea un nuevo repositorio en GitHub.
2. Sube los archivos de este proyecto.
3. Ve a **Settings > Pages**.
4. En *Source*, selecciona la rama `main` y carpeta `/root`.
5. Guarda los cambios y tu sitio estará disponible en:

```
https://tu-usuario.github.io/nombre-del-repositorio
```

## 👨‍🎓 Autor

**Arellano Reyes Emiliano Aaron**  
*CETis 054 - Submódulo Desarrollo de Aplicaciones Web*  
*Docente: Mtra. Laura González*  
*Entrega: 18 de agosto de 2025*

---
💡 Este proyecto busca integrar conocimientos de **Derecho** con el **diseño y desarrollo web**, 
fomentando el aprendizaje práctico y la creatividad digital.
